import {Hero} from "./hero";

export const HEROES: Hero[]= [
  {id: 1,   name: "ali"},
  {id: 2,   name: "mohammad"},
  {id: 3,   name: "hassan"},
  {id: 4,   name: "hussein"},
  {id: 5,   name: "yousef"},
  {id: 6,   name: "ibrahim"},
  {id: 7,   name: "moussa"},
  {id: 8,   name: "ismail"},
  {id: 9,   name: "farah"},
  {id: 10,  name: "khalid"},
  {id: 11,  name: "antar"},
]


